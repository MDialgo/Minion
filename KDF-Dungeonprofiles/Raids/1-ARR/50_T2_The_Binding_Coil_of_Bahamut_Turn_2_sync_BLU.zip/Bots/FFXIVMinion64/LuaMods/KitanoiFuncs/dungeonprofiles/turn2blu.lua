local tbl = {
	name = "turn2blu",
	mesh = "[Mist] turn2blu",
	dutyid = 242,
	level = 50,
	expansion = 2,
	creator = "Mist#4283",
	notes = "v4",
	queuetype = 1,
	requeuetimer = 5,
	createdate = "2021-10-24",
	objectivedestinations = {
		[1] = {objective = 1, pos = {x = 0.67, y = -65.80, z = 79.55}} -- Defeat the ADS
	},
	forcemeleerange = {1459},
	-- forcemeleerange = {
	--   1471, -- Monitoring Node
	--   1472, -- Defense Node
	--   1473, -- Disposal Node
	--   1459, -- ADS
	-- },
	interacts = {},
	enemytargetdistance = 50,
	prioritytarget = {},
	advancedavoid = {},
	hasbuff = {},
	excludeavoid = {
		675,
		1216,
		1217, -- Repelling Cannons
		1226,
	},
	enemylos = true,
	dontcastwhenmoving = false,
}

return tbl